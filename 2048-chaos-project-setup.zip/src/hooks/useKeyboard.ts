import { useEffect } from "react";
import type { Direction } from "@/types";

export type KeyAction = Direction | "undo" | "restart";

const KEY_MAP: Record<string, Direction> = {
  ArrowUp: "up",
  ArrowDown: "down",
  ArrowLeft: "left",
  ArrowRight: "right",
  w: "up",
  s: "down",
  a: "left",
  d: "right",
  W: "up",
  S: "down",
  A: "left",
  D: "right",
};

export function useKeyboard(onAction: (action: KeyAction) => void): void {
  useEffect(() => {
    const handle = (event: KeyboardEvent) => {
      const direction = KEY_MAP[event.key];
      if (direction) {
        event.preventDefault();
        onAction(direction);
        return;
      }
      if (event.key === "z" || event.key === "Z") {
        event.preventDefault();
        onAction("undo");
      } else if (event.key === "r" || event.key === "R") {
        event.preventDefault();
        onAction("restart");
      }
    };

    window.addEventListener("keydown", handle);
    return () => window.removeEventListener("keydown", handle);
  }, [onAction]);
}
