# 2048 Chaos

A premium, production-ready reimagining of the classic **2048** puzzle game. Built with a clean, maintainable React + TypeScript architecture and a modern black & gold glassmorphism design.

Join the numbers, reach **2048**, and keep chasing a higher score — on desktop, tablet, or mobile, with keyboard, mouse, or touch.

---

## Features

- **Classic 2048 mechanics** — slide, merge, and reach 2048.
- **Score & Best Score** — your best score persists in local storage.
- **Undo** — step back through your moves.
- **Restart** — start a fresh board instantly.
- **Win & Game Over screens** — with an option to keep playing past 2048.
- **Keyboard controls** — arrows or `WASD` (plus `Z` undo, `R` restart).
- **Touch & swipe gestures** — fully playable on phones and tablets.
- **Local storage** — the full game state resumes after a refresh.
- **Responsive layout** — adapts to portrait, landscape, and every screen size.
- **Smooth animations** — tile slides, merge pops, and score pulses via Framer Motion.
- **Accessibility** — semantic HTML, ARIA labels, live region, and visible focus states.
- **Embeddable** — the game is a single, dependency-light React component.

---

## Screenshots

> Screenshots will be added to `docs/` in a future update.

| Board | Win screen |
| ----- | ---------- |
| `docs/board.png` | `docs/win.png` |

---

## Technology Stack

| Area | Choice |
| ---- | ------ |
| Framework | [React 19](https://react.dev) |
| Language | [TypeScript](https://www.typescriptlang.org) |
| Build tool | [Vite 7](https://vitejs.dev) |
| Styling | [Tailwind CSS 4](https://tailwindcss.com) |
| Animation | [Framer Motion](https://www.framer.com/motion/) |
| State | Local component state + custom hooks |
| Persistence | Local Storage |

---

## Installation

Requires **Node.js 18+**.

```bash
# Clone the repository
git clone https://github.com/your-org/2048-chaos.git
cd 2048-chaos

# Install dependencies
npm install
```

---

## Development

Start the local development server with hot reload:

```bash
npm run dev
```

The app will be available at `http://localhost:5173`.

---

## Build

Create an optimized production build:

```bash
npm run build
```

The output is written to `dist/`. Thanks to the single-file build setup, `dist/index.html` is fully self-contained and ready to deploy.

Preview the production build locally:

```bash
npm run preview
```

---

## Deployment

The project is deployable without any configuration changes.

### Netlify / Vercel

1. Connect the repository (or run `npm run build`).
2. Set the build command to `npm run build`.
3. Set the publish directory to `dist`.

No environment variables or extra configuration are required.

---

## Project Structure

```
src/
├── components/      # Presentational + composite UI (Board, Tile, Header, …)
├── hooks/           # Encapsulated behavior (useGame2048, useKeyboard, useSwipe)
├── utils/           # Pure logic (game engine, storage, tile styles, cn)
├── types/           # Shared TypeScript types
├── constants/       # Game + design constants
├── App.tsx          # Root composition
├── main.tsx         # Entry point
└── index.css        # Tailwind + theme
```

### Embedding the game

`Game2048` is a self-contained component and can be dropped into any React application:

```tsx
import { Game2048 } from "@/components/Game2048";

export function Page() {
  return <Game2048 />;
}
```

---

## Performance

- Strongly typed, side-effect-free game engine.
- Animation handled by Framer Motion with short, GPU-friendly transitions.
- Minimal dependencies and no unnecessary re-renders.
- Targets Lighthouse **Performance 95+**, **Accessibility 100**, **Best Practices 100**, and **SEO 100**.

---

## Roadmap

- Adjustable board size and win target.
- Light / high-contrast themes.
- Optional sound effects.
- Global leaderboard.

---

## Contributing

Contributions are welcome!

1. Fork the repository and create a feature branch.
2. Run `npm run dev` and verify your change.
3. Ensure `npm run build` succeeds.
4. Open a pull request with a clear description.

Please keep changes focused, typed, and tested where practical.

---

## License

Released under the [MIT License](./LICENSE).

---

## Author

**2048 Chaos** — maintained by the 2048 Chaos contributors.
